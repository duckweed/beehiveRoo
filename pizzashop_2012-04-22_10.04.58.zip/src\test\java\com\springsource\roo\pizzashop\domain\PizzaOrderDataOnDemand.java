package com.springsource.roo.pizzashop.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = PizzaOrder.class)
public class PizzaOrderDataOnDemand {
}
